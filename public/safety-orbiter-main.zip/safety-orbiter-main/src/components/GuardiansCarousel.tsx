import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface Guardian {
  id: string;
  name: string;
  avatar?: string;
  relationship: string;
}

const mockGuardians: Guardian[] = [
  { id: "1", name: "Mom", relationship: "Mother", avatar: "" },
  { id: "2", name: "Dad", relationship: "Father", avatar: "" },
  { id: "3", name: "Sarah", relationship: "Sister", avatar: "" },
  { id: "4", name: "John", relationship: "Friend", avatar: "" },
  { id: "5", name: "Dr. Smith", relationship: "Emergency Contact", avatar: "" },
];

export const GuardiansCarousel = () => {
  return (
    <div className="px-4">
      <h2 className="text-lg font-semibold mb-3 text-foreground">My Guardians</h2>
      <div className="flex gap-3 overflow-x-auto pb-4 scrollbar-hide">
        {mockGuardians.map((guardian) => (
          <Card key={guardian.id} className="flex-shrink-0 w-20 bg-card border-border hover:bg-accent/50 transition-colors cursor-pointer">
            <CardContent className="p-3 text-center">
              <Avatar className="w-10 h-10 mx-auto mb-2">
                <AvatarImage src={guardian.avatar} alt={guardian.name} />
                <AvatarFallback className="bg-primary/10 text-primary text-xs font-medium">
                  {guardian.name.charAt(0)}
                </AvatarFallback>
              </Avatar>
              <p className="text-xs font-medium text-foreground truncate">{guardian.name}</p>
              <p className="text-xs text-muted-foreground truncate">{guardian.relationship}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};