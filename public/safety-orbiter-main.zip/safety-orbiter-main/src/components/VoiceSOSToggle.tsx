import { useState, useEffect } from "react";
import { Mic, MicOff } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";

// Web Speech API types
interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start(): void;
  stop(): void;
  onstart: ((this: SpeechRecognition, ev: Event) => any) | null;
  onresult: ((this: SpeechRecognition, ev: SpeechRecognitionEvent) => any) | null;
  onerror: ((this: SpeechRecognition, ev: SpeechRecognitionErrorEvent) => any) | null;
  onend: ((this: SpeechRecognition, ev: Event) => any) | null;
}

interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList;
}

interface SpeechRecognitionErrorEvent extends Event {
  error: string;
}

declare global {
  interface Window {
    webkitSpeechRecognition: {
      new (): SpeechRecognition;
    };
  }
}

export const VoiceSOSToggle = () => {
  const [isVoiceSOSActive, setIsVoiceSOSActive] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    let recognition: SpeechRecognition | null = null;

    if (isVoiceSOSActive && 'webkitSpeechRecognition' in window) {
      recognition = new (window as any).webkitSpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: SpeechRecognitionEvent) => {
        const transcript = Array.from(event.results)
          .map(result => result[0].transcript)
          .join('')
          .toLowerCase();

        if (transcript.includes('help me') || transcript.includes('emergency')) {
          triggerSOS();
          recognition?.stop();
        }
      };

      recognition.onerror = () => {
        setIsListening(false);
        setIsVoiceSOSActive(false);
        toast({
          title: "Voice SOS Error",
          description: "Unable to access microphone. Please check permissions.",
          variant: "destructive",
        });
      };

      recognition.onend = () => {
        setIsListening(false);
        if (isVoiceSOSActive) {
          // Restart listening if still active
          setTimeout(() => recognition?.start(), 1000);
        }
      };

      recognition.start();
    }

    return () => {
      if (recognition) {
        recognition.stop();
        setIsListening(false);
      }
    };
  }, [isVoiceSOSActive]);

  const triggerSOS = () => {
    toast({
      title: "VOICE SOS ACTIVATED",
      description: "Emergency services contacted via voice command. Stay calm.",
      variant: "destructive",
    });
  };

  const handleToggle = (checked: boolean) => {
    if (checked && !('webkitSpeechRecognition' in window)) {
      toast({
        title: "Voice SOS Unavailable",
        description: "Your browser doesn't support voice recognition.",
        variant: "destructive",
      });
      return;
    }

    setIsVoiceSOSActive(checked);
    
    if (checked) {
      toast({
        title: "Voice SOS Activated",
        description: "Say 'Help Me' or 'Emergency' to trigger SOS",
      });
    } else {
      toast({
        title: "Voice SOS Deactivated",
        description: "Voice commands are now disabled",
      });
    }
  };

  return (
    <div className="bg-card/50 backdrop-blur-sm border border-border/50 rounded-xl p-4">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-3">
          {isListening ? (
            <Mic className="w-5 h-5 text-primary animate-pulse" />
          ) : (
            <MicOff className="w-5 h-5 text-muted-foreground" />
          )}
          <div>
            <h3 className="font-semibold text-foreground">Voice SOS</h3>
            <p className="text-sm text-muted-foreground">
              {isListening ? "Listening for 'Help Me'..." : "Activate voice commands"}
            </p>
          </div>
        </div>
        <Switch
          checked={isVoiceSOSActive}
          onCheckedChange={handleToggle}
        />
      </div>
      
      {isVoiceSOSActive && (
        <div className="text-xs text-muted-foreground mt-2 p-2 bg-primary/10 rounded-lg">
          Say "Help Me" or "Emergency" to trigger SOS
        </div>
      )}
    </div>
  );
};