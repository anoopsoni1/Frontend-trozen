import { Home, Users, Settings } from "lucide-react";

interface NavItem {
  icon: typeof Home;
  label: string;
  active?: boolean;
}

export const BottomNavigation = () => {
  const navItems: NavItem[] = [
    { icon: Home, label: "Home", active: true },
    { icon: Users, label: "Guardians" },
    { icon: Settings, label: "Settings" }
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-card/95 backdrop-blur-lg border-t border-border/50">
      <div className="flex justify-around py-3 px-6">
        {navItems.map(({ icon: IconComponent, label, active }) => (
          <button
            key={label}
            className={`
              flex flex-col items-center gap-1 p-2 rounded-lg
              transition-all duration-200 hover:bg-muted/50
              ${active 
                ? 'text-primary bg-primary/10' 
                : 'text-muted-foreground hover:text-foreground'
              }
            `}
          >
            <IconComponent className={`w-5 h-5 ${active ? 'drop-shadow-sm' : ''}`} />
            <span className="text-xs font-medium">{label}</span>
          </button>
        ))}
      </div>
    </div>
  );
};