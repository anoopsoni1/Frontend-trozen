import { MapPin, Navigation } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";

export const RoutePlanner = () => {
  return (
    <Card className="p-6 bg-gradient-card border-border/50 animate-fade-in">
      <div className="space-y-4">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 rounded-lg bg-primary/10">
            <Navigation className="w-5 h-5 text-primary" />
          </div>
          <h2 className="text-lg font-semibold text-foreground">Safe Route Planner</h2>
        </div>
        
        <div className="space-y-4">
          <div className="relative">
            <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Start location" 
              className="pl-10 bg-input border-border/50 focus:border-primary transition-all"
            />
          </div>
          
          <div className="relative">
            <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="End destination" 
              className="pl-10 bg-input border-border/50 focus:border-primary transition-all"
            />
          </div>
          
          <Button variant="secondary" className="w-full mt-4">
            <Navigation className="w-4 h-4 mr-2" />
            Plan Safe Route
          </Button>
        </div>
      </div>
    </Card>
  );
};