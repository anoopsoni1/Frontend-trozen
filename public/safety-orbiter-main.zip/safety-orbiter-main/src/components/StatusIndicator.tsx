import { Shield, CheckCircle, MapPin } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface StatusIndicatorProps {
  status: "safe" | "warning" | "danger";
}

export const StatusIndicator = ({ status = "safe" }: StatusIndicatorProps) => {
  const statusConfig = {
    safe: {
      color: "text-safe-foreground bg-safe",
      icon: CheckCircle,
      text: "Status: Safe",
      glow: "shadow-glow-green"
    },
    warning: {
      color: "text-warning-foreground bg-warning",
      icon: Shield,
      text: "Status: Alert",
      glow: ""
    },
    danger: {
      color: "text-danger-foreground bg-danger",
      icon: Shield,
      text: "Status: Emergency",
      glow: "shadow-glow-orange"
    }
  };

  const config = statusConfig[status];
  const IconComponent = config.icon;

  return (
    <div className="p-4">
      <Card className="bg-card border-border">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Live Safety Status</h3>
              <div className="flex items-center gap-2 mt-1">
                <MapPin className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm">Current Location: IIITM Campus</span>
              </div>
            </div>
            <div className={`
              flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium
              ${config.color}
            `}>
              <IconComponent className="w-4 h-4" />
              <span className="text-xs">{status === 'safe' ? 'Safe' : status === 'warning' ? 'Alert' : 'Emergency'}</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};