import { Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export const SOSButton = () => {
  const { toast } = useToast();

  const handleSOSPress = () => {
    toast({
      title: "SOS Activated",
      description: "Emergency services have been contacted. Stay calm.",
      variant: "destructive",
    });
  };

  return (
    <div className="flex justify-center pb-8">
        <Button
        onClick={handleSOSPress}
        variant="sos"
        size="sos"
      >
        <div className="text-center">
          <Phone className="w-8 h-8 mb-1" />
          <div className="text-xs">SOS</div>
        </div>
      </Button>
    </div>
  );
};