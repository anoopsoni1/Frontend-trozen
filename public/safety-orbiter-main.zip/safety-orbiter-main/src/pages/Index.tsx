import { StatusIndicator } from "@/components/StatusIndicator";
import { RoutePlanner } from "@/components/RouteePlanner";
import { SOSButton } from "@/components/SOSButton";
import { VoiceSOSToggle } from "@/components/VoiceSOSToggle";
import { BottomNavigation } from "@/components/BottomNavigation";
import { GuardiansCarousel } from "@/components/GuardiansCarousel";

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-background text-foreground font-sans">
      {/* Status Header */}
      <div className="pt-safe-area-top">
        <StatusIndicator status="safe" />
      </div>

      {/* Main Content */}
      <div className="pb-24 space-y-6 max-w-md mx-auto">
        {/* Guardians Carousel */}
        <div className="mt-6">
          <GuardiansCarousel />
        </div>

        {/* Route Planner Section */}
        <div className="px-4">
          <RoutePlanner />
        </div>

        {/* Voice SOS Toggle */}
        <div className="px-4">
          <VoiceSOSToggle />
        </div>

        {/* Spacer to push SOS button down */}
        <div className="h-40"></div>
      </div>

      {/* SOS Button - Fixed positioning */}
      <div className="fixed bottom-20 left-1/2 transform -translate-x-1/2 z-10">
        <SOSButton />
      </div>

      {/* Bottom Navigation */}
      <BottomNavigation />
    </div>
  );
};

export default Index;
